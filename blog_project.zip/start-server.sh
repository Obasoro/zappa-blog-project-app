
#!/bin/bash
        
# Build Project
docker-compose build

# Start Server
docker-compose up -d
